import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { NAV_ITEMS } from '../constants';
import { LogOut, ShieldAlert } from 'lucide-react';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isAdmin } = useAuth();

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Top Header */}
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/')}>
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center font-bold text-white">
              G
            </div>
            <span className="font-bold text-lg bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-amber-200">
              BD GameShop
            </span>
          </div>

          <div className="flex items-center gap-3">
             {isAdmin && (
                <button 
                  onClick={() => navigate('/admin')}
                  className="p-2 text-red-500 hover:bg-red-500/10 rounded-full"
                  title="Admin Panel"
                >
                  <ShieldAlert size={20} />
                </button>
             )}
            {user ? (
              <button 
                onClick={handleLogout}
                className="p-2 text-slate-400 hover:text-white"
              >
                <LogOut size={20} />
              </button>
            ) : (
              <button 
                onClick={() => navigate('/login')}
                className="text-sm font-medium text-orange-500 hover:text-orange-400"
              >
                Login
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-md mx-auto p-4 pb-24">
        {children}
      </main>

      {/* Bottom Navigation (Mobile First) */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 z-50 md:hidden">
        <div className="flex justify-around items-center h-16">
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
                  isActive ? 'text-orange-500' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                <Icon size={20} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
      
      {/* Desktop Navigation Hint */}
      <div className="hidden md:block fixed bottom-4 right-4 text-slate-500 text-xs">
        Mobile-first design preview
      </div>
    </div>
  );
};