import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../firebase';
import { Product } from '../types';
import { CATEGORIES } from '../constants';
import { ArrowLeft, Loader2 } from 'lucide-react';

export const ProductList: React.FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const categoryInfo = CATEGORIES.find(c => c.id === categoryId);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const q = query(
          collection(db, 'products'),
          where('category', '==', categoryId)
        );
        const querySnapshot = await getDocs(q);
        const fetched: Product[] = [];
        querySnapshot.forEach((doc) => {
          fetched.push(doc.data() as Product);
        });
        // Sort by price
        fetched.sort((a, b) => a.price - b.price);
        setProducts(fetched);
      } catch (err) {
        console.error("Failed to load products", err);
      } finally {
        setLoading(false);
      }
    };

    if (categoryId) fetchProducts();
  }, [categoryId]);

  if (loading) {
    return <div className="flex justify-center pt-20"><Loader2 className="animate-spin text-orange-500" /></div>;
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-800 rounded-full">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-xl font-bold">{categoryInfo?.title || 'Products'}</h1>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {products.map((product) => (
          <div 
            key={product.id}
            onClick={() => navigate(`/checkout/${product.id}`)}
            className="bg-slate-900 border border-slate-800 rounded-xl p-3 cursor-pointer hover:border-orange-500/50 hover:bg-slate-800 transition-all"
          >
            <div className="relative aspect-square mb-3 rounded-lg overflow-hidden bg-slate-950">
                <img src={product.imageUrl || 'https://picsum.photos/200'} alt={product.title} className="w-full h-full object-cover" />
            </div>
            <h3 className="font-semibold text-sm mb-1 truncate">{product.title}</h3>
            <div className="flex items-end justify-between">
                <div className="flex flex-col">
                    {product.originalPrice && (
                        <span className="text-xs text-slate-500 line-through">৳{product.originalPrice}</span>
                    )}
                    <span className="text-orange-500 font-bold">৳{product.price}</span>
                </div>
                <button className="bg-orange-600 text-white text-xs px-2 py-1 rounded">
                    Buy
                </button>
            </div>
          </div>
        ))}
      </div>
      
      {products.length === 0 && (
        <div className="text-center py-20 text-slate-500">
            No products found in this category.
        </div>
      )}
    </div>
  );
};