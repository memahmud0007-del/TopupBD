import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { collection, getDocs, query, orderBy, doc, updateDoc, deleteDoc, addDoc, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { Order, Product, OrderStatus, AdminSettings } from '../types';
import { Loader2, Plus, Trash2, Edit2 } from 'lucide-react';
import { CATEGORIES } from '../constants';

export const Admin: React.FC = () => {
    const { isAdmin, loading } = useAuth();
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'settings'>('orders');

    useEffect(() => {
        if (!loading && !isAdmin) {
            navigate('/');
        }
    }, [isAdmin, loading, navigate]);

    if (loading || !isAdmin) return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;

    return (
        <div className="pb-20">
            <h1 className="text-2xl font-bold mb-6 text-red-500">Admin Dashboard</h1>
            
            {/* Admin Tabs */}
            <div className="flex gap-2 overflow-x-auto pb-4 mb-4 no-scrollbar">
                {['orders', 'products', 'settings'].map(tab => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab as any)}
                        className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap ${activeTab === tab ? 'bg-white text-black' : 'bg-slate-900 text-slate-400'}`}
                    >
                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                ))}
            </div>

            {activeTab === 'orders' && <AdminOrders />}
            {activeTab === 'products' && <AdminProducts />}
            {activeTab === 'settings' && <AdminSettingsPanel />}
        </div>
    );
};

const AdminOrders = () => {
    const [orders, setOrders] = useState<Order[]>([]);
    
    const fetchOrders = async () => {
        const q = query(collection(db, 'orders'), orderBy('timestamp', 'desc'));
        const snap = await getDocs(q);
        const data: Order[] = [];
        snap.forEach(doc => data.push({ ...doc.data(), id: doc.id } as Order));
        setOrders(data);
    };

    useEffect(() => { fetchOrders(); }, []);

    const updateStatus = async (id: string, status: OrderStatus) => {
        if(!confirm(`Mark order as ${status}?`)) return;
        await updateDoc(doc(db, 'orders', id), { status });
        fetchOrders();
    };

    return (
        <div className="space-y-4">
            {orders.map(order => (
                <div key={order.id} className="bg-slate-900 p-4 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-start">
                        <div>
                            <span className="text-xs text-slate-500">{order.id}</span>
                            <h3 className="font-bold">{order.productTitle}</h3>
                            <p className="text-sm">User: {order.userEmail}</p>
                            <p className="text-sm font-mono text-orange-400">{order.playerInput}</p>
                            {order.paymentMethod === 'bkash_manual' && (
                                <div className="text-xs text-pink-500 mt-1">
                                    Trx: {order.transactionId} | From: {order.senderNumber}
                                </div>
                            )}
                        </div>
                        <div className="text-right">
                             <div className="font-bold text-lg mb-2">৳{order.amount}</div>
                             <div className={`text-xs uppercase font-bold mb-2 ${order.status === 'pending' ? 'text-yellow-500' : order.status === 'completed' ? 'text-green-500' : 'text-slate-500'}`}>
                                {order.status}
                             </div>
                        </div>
                    </div>
                    {order.status === 'pending' && (
                        <div className="flex gap-2 mt-3 pt-3 border-t border-slate-800">
                            <button onClick={() => updateStatus(order.id, OrderStatus.PROCESSING)} className="flex-1 bg-blue-600 py-1 rounded text-xs font-bold">Process</button>
                            <button onClick={() => updateStatus(order.id, OrderStatus.COMPLETED)} className="flex-1 bg-green-600 py-1 rounded text-xs font-bold">Complete</button>
                            <button onClick={() => updateStatus(order.id, OrderStatus.CANCELLED)} className="flex-1 bg-red-600 py-1 rounded text-xs font-bold">Reject</button>
                        </div>
                    )}
                     {order.status === 'processing' && (
                        <div className="flex gap-2 mt-3 pt-3 border-t border-slate-800">
                            <button onClick={() => updateStatus(order.id, OrderStatus.COMPLETED)} className="w-full bg-green-600 py-1 rounded text-xs font-bold">Mark Completed</button>
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};

const AdminProducts = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [isEditing, setIsEditing] = useState(false);
    const [editForm, setEditForm] = useState<Partial<Product>>({});

    const fetchProducts = async () => {
        const snap = await getDocs(collection(db, 'products'));
        const data: Product[] = [];
        snap.forEach(doc => data.push({ ...doc.data(), id: doc.id } as Product));
        setProducts(data);
    };

    useEffect(() => { fetchProducts(); }, []);

    const handleDelete = async (id: string) => {
        if(confirm("Delete product?")) {
            await deleteDoc(doc(db, 'products', id));
            fetchProducts();
        }
    };

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        const productData = {
            ...editForm,
            price: Number(editForm.price),
            originalPrice: Number(editForm.originalPrice || 0)
        };

        if (editForm.id) {
            await updateDoc(doc(db, 'products', editForm.id), productData);
        } else {
            await addDoc(collection(db, 'products'), productData);
        }
        setIsEditing(false);
        setEditForm({});
        fetchProducts();
    };

    return (
        <div>
            {!isEditing ? (
                <>
                    <button onClick={() => { setEditForm({}); setIsEditing(true); }} className="w-full bg-orange-600 py-2 rounded-lg font-bold mb-4 flex items-center justify-center gap-2">
                        <Plus size={18} /> Add Product
                    </button>
                    <div className="space-y-3">
                        {products.map(p => (
                            <div key={p.id} className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex justify-between items-center">
                                <div className="flex gap-3 items-center">
                                    <img src={p.imageUrl} className="w-10 h-10 rounded bg-slate-800 object-cover" />
                                    <div>
                                        <div className="font-bold text-sm">{p.title}</div>
                                        <div className="text-xs text-orange-500 font-bold">৳{p.price}</div>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => { setEditForm(p); setIsEditing(true); }} className="p-2 bg-slate-800 rounded text-blue-400"><Edit2 size={16}/></button>
                                    <button onClick={() => handleDelete(p.id)} className="p-2 bg-slate-800 rounded text-red-400"><Trash2 size={16}/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            ) : (
                <form onSubmit={handleSave} className="space-y-4 bg-slate-900 p-4 rounded-xl border border-slate-800">
                    <h3 className="font-bold">{editForm.id ? 'Edit Product' : 'New Product'}</h3>
                    <input className="w-full bg-slate-950 p-2 rounded border border-slate-800" placeholder="Title" value={editForm.title || ''} onChange={e => setEditForm({...editForm, title: e.target.value})} required />
                    <select className="w-full bg-slate-950 p-2 rounded border border-slate-800" value={editForm.category || ''} onChange={e => setEditForm({...editForm, category: e.target.value})} required>
                        <option value="">Select Category</option>
                        {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                    </select>
                    <div className="grid grid-cols-2 gap-2">
                         <input type="number" className="w-full bg-slate-950 p-2 rounded border border-slate-800" placeholder="Price" value={editForm.price || ''} onChange={e => setEditForm({...editForm, price: Number(e.target.value)})} required />
                         <input type="number" className="w-full bg-slate-950 p-2 rounded border border-slate-800" placeholder="Original Price" value={editForm.originalPrice || ''} onChange={e => setEditForm({...editForm, originalPrice: Number(e.target.value)})} />
                    </div>
                    <input className="w-full bg-slate-950 p-2 rounded border border-slate-800" placeholder="Image URL" value={editForm.imageUrl || ''} onChange={e => setEditForm({...editForm, imageUrl: e.target.value})} required />
                    <select className="w-full bg-slate-950 p-2 rounded border border-slate-800" value={editForm.inputType || 'uid'} onChange={e => setEditForm({...editForm, inputType: e.target.value as any})}>
                        <option value="uid">UID Input</option>
                        <option value="id_code">Code Input</option>
                    </select>
                    <div className="flex gap-2">
                        <button type="button" onClick={() => setIsEditing(false)} className="flex-1 bg-slate-700 py-2 rounded">Cancel</button>
                        <button type="submit" className="flex-1 bg-green-600 py-2 rounded">Save</button>
                    </div>
                </form>
            )}
        </div>
    );
};

const AdminSettingsPanel = () => {
    const [settings, setSettings] = useState<AdminSettings>({ bkashNumber: '', notice: '', bannerUrl: '' });
    
    useEffect(() => {
        const load = async () => {
            const q = query(collection(db, 'adminSettings'), limit(1));
            const snap = await getDocs(q);
            if(!snap.empty) {
                setSettings(snap.docs[0].data() as AdminSettings);
            }
        };
        load();
    }, []);

    const save = async () => {
        // Assuming single doc for settings, logic simplified
        const q = query(collection(db, 'adminSettings'), limit(1));
        const snap = await getDocs(q);
        if (snap.empty) {
            await addDoc(collection(db, 'adminSettings'), settings);
        } else {
            await updateDoc(snap.docs[0].ref, settings as any);
        }
        alert("Saved!");
    };

    return (
        <div className="space-y-4">
             <div className="bg-slate-900 p-4 rounded-xl space-y-3">
                <label className="block text-sm text-slate-400">BKash Number</label>
                <input value={settings.bkashNumber} onChange={e => setSettings({...settings, bkashNumber: e.target.value})} className="w-full bg-slate-950 p-2 rounded border border-slate-800 text-pink-500 font-bold" />
                
                <label className="block text-sm text-slate-400">Marquee Notice</label>
                <input value={settings.notice} onChange={e => setSettings({...settings, notice: e.target.value})} className="w-full bg-slate-950 p-2 rounded border border-slate-800" />
                
                <label className="block text-sm text-slate-400">Banner Image URL</label>
                <input value={settings.bannerUrl} onChange={e => setSettings({...settings, bannerUrl: e.target.value})} className="w-full bg-slate-950 p-2 rounded border border-slate-800" />
                
                <button onClick={save} className="w-full bg-blue-600 py-2 rounded font-bold mt-2">Update Settings</button>
             </div>
        </div>
    );
};