import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { User, Wallet, ShieldCheck, History, LogOut } from 'lucide-react';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase';

export const Profile: React.FC = () => {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();

  if (!user) {
    navigate('/login');
    return null;
  }

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center justify-center py-6">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-orange-500 flex items-center justify-center mb-3">
            <User size={32} className="text-slate-400" />
        </div>
        <h2 className="text-xl font-bold">{userProfile?.displayName || user.email}</h2>
        <p className="text-sm text-slate-500">{user.email}</p>
        <span className="mt-2 text-xs bg-slate-800 text-orange-400 px-3 py-1 rounded-full border border-slate-700">
            {userProfile?.role === 'admin' ? 'Administrator' : 'Verified Member'}
        </span>
      </div>

      {/* Wallet Card */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 border border-slate-700 p-6 rounded-xl flex items-center justify-between shadow-lg">
        <div>
            <p className="text-slate-400 text-sm mb-1">Total Balance</p>
            <h1 className="text-3xl font-bold text-white">৳ {userProfile?.balance || 0}</h1>
        </div>
        <div className="p-3 bg-orange-500/10 rounded-full text-orange-500 border border-orange-500/20">
            <Wallet size={24} />
        </div>
      </div>

      {/* Menu */}
      <div className="space-y-2">
        <button onClick={() => navigate('/orders')} className="w-full bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center gap-3 hover:bg-slate-800 transition-colors">
            <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500"><History size={20} /></div>
            <span className="font-medium">My Orders</span>
        </button>
        
        {userProfile?.role === 'admin' && (
            <button onClick={() => navigate('/admin')} className="w-full bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center gap-3 hover:bg-slate-800 transition-colors">
                <div className="p-2 bg-red-500/10 rounded-lg text-red-500"><ShieldCheck size={20} /></div>
                <span className="font-medium">Admin Panel</span>
            </button>
        )}

        <button onClick={handleLogout} className="w-full bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center gap-3 hover:bg-slate-800 transition-colors">
            <div className="p-2 bg-slate-500/10 rounded-lg text-slate-500"><LogOut size={20} /></div>
            <span className="font-medium text-slate-400">Logout</span>
        </button>
      </div>
    </div>
  );
};