import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CATEGORIES } from '../constants';
import { collection, getDocs, query, where, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { AdminSettings } from '../types';

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const [bannerUrl, setBannerUrl] = useState("https://picsum.photos/800/400?grayscale");
  const [notice, setNotice] = useState("Welcome to BD Game TopUp!");

  useEffect(() => {
    const fetchSettings = async () => {
        try {
            const q = query(collection(db, 'adminSettings'), limit(1));
            const snap = await getDocs(q);
            if(!snap.empty) {
                const data = snap.docs[0].data() as AdminSettings;
                if(data.bannerUrl) setBannerUrl(data.bannerUrl);
                if(data.notice) setNotice(data.notice);
            }
        } catch (e) {
            console.log("Using default settings");
        }
    };
    fetchSettings();
  }, []);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="rounded-xl overflow-hidden shadow-lg border border-slate-800 relative group">
        <img 
          src={bannerUrl} 
          alt="Featured Offer" 
          className="w-full h-48 object-cover transition-transform group-hover:scale-105"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
          <p className="text-white font-bold text-lg">Special Offer</p>
          <p className="text-orange-400 text-sm">Get 10% Bonus on First TopUp!</p>
        </div>
      </div>

      {/* Marquee Notice */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-2 overflow-hidden flex items-center">
        <span className="bg-orange-600 text-[10px] font-bold px-2 py-0.5 rounded mr-2 text-white">NOTICE</span>
        <div className="whitespace-nowrap overflow-hidden w-full">
            <p className="animate-pulse text-sm text-slate-300">{notice}</p>
        </div>
      </div>

      {/* Categories */}
      <section>
        <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <span className="w-1 h-6 bg-orange-500 rounded-full"></span>
          Popular Categories
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {CATEGORIES.map((cat) => (
            <div 
              key={cat.id}
              onClick={() => navigate(`/category/${cat.id}`)}
              className="bg-slate-900 border border-slate-800 hover:border-orange-500/50 p-4 rounded-xl cursor-pointer transition-all hover:bg-slate-800 group"
            >
              <div className="flex flex-col items-center text-center gap-3">
                <div className={`p-3 rounded-full bg-slate-950 group-hover:bg-slate-900 ${cat.color}`}>
                  <cat.icon size={28} />
                </div>
                <h3 className="font-semibold text-sm text-slate-200 group-hover:text-white">{cat.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Action */}
      <div className="bg-gradient-to-r from-orange-600 to-amber-600 rounded-xl p-6 text-center shadow-lg shadow-orange-900/20">
        <h3 className="text-xl font-bold text-white mb-2">Need Help?</h3>
        <p className="text-white/80 text-sm mb-4">Contact our support team for instant assistance.</p>
        <button className="bg-white text-orange-600 px-6 py-2 rounded-full font-bold text-sm hover:bg-slate-100 transition-colors">
          Contact Support
        </button>
      </div>
    </div>
  );
};