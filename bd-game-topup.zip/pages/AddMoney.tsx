import React, { useState, useEffect } from 'react';
import { collection, addDoc, query, limit, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { WalletTransaction, AdminSettings } from '../types';
import { Copy, Loader2, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const AddMoney: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [amount, setAmount] = useState('');
    const [senderNumber, setSenderNumber] = useState('');
    const [trxId, setTrxId] = useState('');
    const [loading, setLoading] = useState(false);
    const [settings, setSettings] = useState<AdminSettings | null>(null);

    useEffect(() => {
        const fetchSettings = async () => {
            const q = query(collection(db, 'adminSettings'), limit(1));
            const snap = await getDocs(q);
            if(!snap.empty) setSettings(snap.docs[0].data() as AdminSettings);
        };
        fetchSettings();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!user) return;
        setLoading(true);
        try {
            const transaction: WalletTransaction = {
                id: `TRX-${Date.now()}`,
                userId: user.uid,
                amount: Number(amount),
                type: 'credit',
                description: 'Add Money Request',
                status: 'pending',
                timestamp: Date.now(),
                bkashNumber: senderNumber,
                transactionId: trxId
            };
            await addDoc(collection(db, 'transactions'), transaction);
            alert("Request submitted! Please wait for admin approval.");
            navigate('/profile');
        } catch(e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-3">
                <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-800 rounded-full">
                    <ArrowLeft size={20} />
                </button>
                <h1 className="text-xl font-bold">Add Money</h1>
            </div>

            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                <h3 className="text-slate-400 text-sm mb-2">Send Money to this BKash Personal</h3>
                <div className="bg-slate-950 p-3 rounded flex justify-between items-center border border-pink-500/30">
                    <span className="text-pink-500 font-bold font-mono text-lg">{settings?.bkashNumber || 'Loading...'}</span>
                    <button onClick={() => {navigator.clipboard.writeText(settings?.bkashNumber || ''); alert("Copied!")}} className="text-slate-400">
                        <Copy size={18} />
                    </button>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="text-sm text-slate-400">Amount (৳)</label>
                    <input 
                        type="number"
                        required
                        min="50"
                        value={amount}
                        onChange={e => setAmount(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-orange-500 outline-none"
                    />
                </div>
                <div>
                    <label className="text-sm text-slate-400">Sender Number</label>
                    <input 
                        type="text"
                        required
                        value={senderNumber}
                        onChange={e => setSenderNumber(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-orange-500 outline-none"
                    />
                </div>
                <div>
                    <label className="text-sm text-slate-400">Transaction ID</label>
                    <input 
                        type="text"
                        required
                        value={trxId}
                        onChange={e => setTrxId(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-orange-500 outline-none"
                    />
                </div>
                <button 
                    disabled={loading}
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-lg flex justify-center"
                >
                    {loading ? <Loader2 className="animate-spin" /> : 'Submit Request'}
                </button>
            </form>
        </div>
    );
};