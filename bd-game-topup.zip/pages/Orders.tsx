import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Order, OrderStatus } from '../types';
import { Loader2, Copy } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const Orders: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
        navigate('/login');
        return;
    }
    const fetchOrders = async () => {
        try {
            const q = query(
                collection(db, 'orders'),
                where('userId', '==', user.uid),
                orderBy('timestamp', 'desc')
            );
            const snap = await getDocs(q);
            const fetched: Order[] = [];
            snap.forEach(doc => fetched.push(doc.data() as Order));
            setOrders(fetched);
        } catch (e) {
            console.error("Fetch orders error", e);
        } finally {
            setLoading(false);
        }
    };
    fetchOrders();
  }, [user]);

  if (loading) return <div className="flex justify-center pt-20"><Loader2 className="animate-spin text-orange-500" /></div>;

  const getStatusColor = (status: OrderStatus) => {
      switch(status) {
          case OrderStatus.COMPLETED: return 'text-green-500 bg-green-500/10';
          case OrderStatus.PENDING: return 'text-yellow-500 bg-yellow-500/10';
          case OrderStatus.PROCESSING: return 'text-blue-500 bg-blue-500/10';
          case OrderStatus.CANCELLED: return 'text-red-500 bg-red-500/10';
          default: return 'text-slate-500';
      }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold mb-4">Order History</h1>
      {orders.length === 0 ? (
          <div className="text-center text-slate-500 py-10">No orders found.</div>
      ) : (
          orders.map(order => (
              <div key={order.id} className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                  <div className="flex justify-between items-start mb-2">
                      <div>
                          <h3 className="font-bold text-white">{order.productTitle}</h3>
                          <p className="text-xs text-slate-400">ID: {order.id}</p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${getStatusColor(order.status)}`}>
                          {order.status}
                      </span>
                  </div>
                  <div className="text-sm text-slate-300 grid grid-cols-2 gap-2 mt-3 bg-slate-950 p-2 rounded">
                      <div>
                          <span className="text-xs text-slate-500 block">Player ID</span>
                          <span className="font-mono">{order.playerInput}</span>
                      </div>
                      <div className="text-right">
                          <span className="text-xs text-slate-500 block">Amount</span>
                          <span className="font-bold text-orange-500">৳{order.amount}</span>
                      </div>
                  </div>
                  <div className="mt-2 text-xs text-slate-500 flex justify-between">
                     <span>{new Date(order.timestamp).toLocaleDateString()}</span>
                     <span>Method: {order.paymentMethod === 'bkash_manual' ? 'BKash' : 'Wallet'}</span>
                  </div>
              </div>
          ))
      )}
    </div>
  );
};