import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, addDoc, getDocs, limit, query, updateDoc, increment } from 'firebase/firestore';
import { db } from '../firebase';
import { Product, Order, OrderStatus, UserProfile, AdminSettings } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, CreditCard, Loader2, Copy, CheckCircle2 } from 'lucide-react';

export const Checkout: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const navigate = useNavigate();
  const { user, userProfile, refreshProfile } = useAuth();
  
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [settings, setSettings] = useState<AdminSettings | null>(null);

  // Form State
  const [playerId, setPlayerId] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'bkash_manual' | 'wallet'>('bkash_manual');
  const [senderNumber, setSenderNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');

  useEffect(() => {
    const init = async () => {
        if (!productId) return;
        setLoading(true);
        try {
            // Fetch Product
            const prodRef = doc(db, 'products', productId);
            const prodSnap = await getDoc(prodRef);
            
            // Fetch Settings (BKash Info)
            const settingsQ = query(collection(db, 'adminSettings'), limit(1));
            const settingsSnap = await getDocs(settingsQ);
            
            if (prodSnap.exists()) {
                setProduct(prodSnap.data() as Product);
            }
            if (!settingsSnap.empty) {
                setSettings(settingsSnap.docs[0].data() as AdminSettings);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };
    init();
  }, [productId]);

  const handleCopyNumber = () => {
    if (settings?.bkashNumber) {
        navigator.clipboard.writeText(settings.bkashNumber);
        alert("Number copied!");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !product) {
        navigate('/login');
        return;
    }
    
    if (paymentMethod === 'wallet' && (userProfile?.balance || 0) < product.price) {
        alert("Insufficient balance!");
        return;
    }

    setSubmitting(true);
    try {
        const orderData: Order = {
            id: `ORD-${Date.now()}`,
            userId: user.uid,
            userEmail: user.email || '',
            productId: product.id,
            productTitle: product.title,
            amount: product.price,
            status: paymentMethod === 'wallet' ? OrderStatus.PROCESSING : OrderStatus.PENDING,
            paymentMethod,
            transactionId: paymentMethod === 'bkash_manual' ? transactionId : `WALLET-${Date.now()}`,
            senderNumber: paymentMethod === 'bkash_manual' ? senderNumber : '',
            playerInput: playerId,
            timestamp: Date.now()
        };

        // If wallet, deduct balance
        if (paymentMethod === 'wallet') {
            const userRef = doc(db, 'users', user.uid);
            await updateDoc(userRef, {
                balance: increment(-product.price)
            });
            await refreshProfile();
        }

        await addDoc(collection(db, 'orders'), orderData);
        navigate('/orders');
    } catch (e) {
        console.error("Order failed", e);
        alert("Order failed. Please try again.");
    } finally {
        setSubmitting(false);
    }
  };

  if (loading || !product) return <div className="flex justify-center py-20"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="pb-10">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-800 rounded-full">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-xl font-bold">Checkout</h1>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6 flex gap-4">
        <img src={product.imageUrl} alt={product.title} className="w-20 h-20 object-cover rounded-lg bg-slate-950" />
        <div>
            <h3 className="font-bold text-lg text-white">{product.title}</h3>
            <p className="text-sm text-slate-400 capitalize">{product.category.replace('-', ' ')}</p>
            <p className="text-orange-500 font-bold mt-1">৳{product.price}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Player ID Section */}
        <section className="space-y-2">
            <label className="text-sm font-medium text-slate-300">
                {product.inputType === 'uid' ? 'Player UID' : 'Player ID Code'} <span className="text-red-500">*</span>
            </label>
            <input 
                type="text" 
                required
                value={playerId}
                onChange={(e) => setPlayerId(e.target.value)}
                placeholder={product.inputType === 'uid' ? '123456789' : 'Enter ID Code'}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-orange-500 focus:outline-none"
            />
        </section>

        {/* Payment Method Selection */}
        <section className="space-y-3">
            <label className="text-sm font-medium text-slate-300">Select Payment</label>
            <div className="grid grid-cols-2 gap-3">
                <button
                    type="button"
                    onClick={() => setPaymentMethod('bkash_manual')}
                    className={`p-3 rounded-lg border flex flex-col items-center justify-center gap-2 ${paymentMethod === 'bkash_manual' ? 'border-pink-500 bg-pink-500/10' : 'border-slate-700 bg-slate-900'}`}
                >
                    <span className="font-bold text-pink-500">Bkash</span>
                    <span className="text-xs text-slate-400">Manual</span>
                </button>
                <button
                    type="button"
                    onClick={() => setPaymentMethod('wallet')}
                    className={`p-3 rounded-lg border flex flex-col items-center justify-center gap-2 ${paymentMethod === 'wallet' ? 'border-orange-500 bg-orange-500/10' : 'border-slate-700 bg-slate-900'}`}
                >
                    <span className="font-bold text-orange-500">Wallet</span>
                    <span className="text-xs text-slate-400">Balance: ৳{userProfile?.balance || 0}</span>
                </button>
            </div>
        </section>

        {/* Manual BKash Instructions */}
        {paymentMethod === 'bkash_manual' && (
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-4">
                <div className="flex justify-between items-center bg-slate-950 p-3 rounded-lg border border-slate-800">
                    <div>
                        <p className="text-xs text-slate-400">Send Money To:</p>
                        <p className="text-lg font-mono font-bold text-pink-500">{settings?.bkashNumber || '01xxxxxxxxx'}</p>
                    </div>
                    <button type="button" onClick={handleCopyNumber} className="text-slate-400 hover:text-white">
                        <Copy size={18} />
                    </button>
                </div>
                
                <div className="text-xs text-slate-400 bg-slate-950/50 p-2 rounded">
                   {settings?.instruction || "Send money using 'Send Money' option. Copy TrxID."}
                </div>

                <div className="space-y-3">
                    <div>
                        <label className="text-xs text-slate-400">Sender Number</label>
                        <input 
                            type="text" 
                            required
                            placeholder="01xxxxxxxxx"
                            value={senderNumber}
                            onChange={(e) => setSenderNumber(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-pink-500"
                        />
                    </div>
                    <div>
                        <label className="text-xs text-slate-400">Transaction ID (TrxID)</label>
                        <input 
                            type="text" 
                            required
                            placeholder="9X7....."
                            value={transactionId}
                            onChange={(e) => setTransactionId(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-pink-500"
                        />
                    </div>
                </div>
            </div>
        )}

        {/* Submit */}
        <button
            type="submit"
            disabled={submitting}
            className="w-full bg-gradient-to-r from-orange-600 to-amber-600 py-3 rounded-lg font-bold text-white shadow-lg hover:brightness-110 active:scale-95 transition-all flex justify-center items-center gap-2"
        >
            {submitting && <Loader2 className="animate-spin" size={20} />}
            Pay ৳{product.price}
        </button>
      </form>
    </div>
  );
};